package com.example.happymusic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
