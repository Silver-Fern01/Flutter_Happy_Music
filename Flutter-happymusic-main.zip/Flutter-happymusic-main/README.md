# happymusic

Music app Is Made with ❤ in **flutter.**



Images : 
Splash Screen  |  Home Sceen - 1 | Home Sceen - 2
:-------------------------:|:-------------------------:|:-------------------------:
![SplashScreen](https://user-images.githubusercontent.com/8991251/170634741-e2262e85-00a3-41dd-a6e8-6bdf6b7b366f.png) | ![Screen-1](https://user-images.githubusercontent.com/8991251/170662084-0d66e21f-8b03-455c-a679-bbe97e6e41a0.png) | ![Screen-2](https://user-images.githubusercontent.com/8991251/170662063-c00a3fa0-f44a-4889-bd1a-9e9712e3084f.png) 
Mini-Player - 1 | Mini-Player - 2 | Coming Soon   
![Mini-Player - 1](https://user-images.githubusercontent.com/8991251/170662019-959b1fce-7a87-4385-8d8a-f406aae092a8.png) | ![Mini-Player - 2](https://user-images.githubusercontent.com/8991251/170662095-71226cfd-c760-4841-94e2-3bb1d284e4ad.png)|![Coming-soon](https://user-images.githubusercontent.com/8991251/170663745-2c581aca-6197-4abd-92ce-a03a8317a290.png)



Videos: 

SplashScreen| HomeScren | ComingSoon
:-------------------------:|:-------------------------:|:-------------------------:
<video src='https://user-images.githubusercontent.com/8991251/170666686-e8ddaac2-c26e-4ac4-a608-0f19e85dfafc.mov' /> | <video src='https://user-images.githubusercontent.com/8991251/170666680-0863257c-fa27-4bb0-ad00-60632f3e7f09.mov' /> | <video src='https://user-images.githubusercontent.com/8991251/170666637-97d83f8f-d399-4b84-90b0-3ccb0f2c1dec.mov' /> 


