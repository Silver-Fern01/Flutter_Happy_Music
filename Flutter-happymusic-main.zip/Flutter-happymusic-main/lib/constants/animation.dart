class AnimationConstants {
  static const String kSplashScreen = "assets/animation/splash-animation.json";
}
